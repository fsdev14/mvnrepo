package com.fd.vplus.dmc.customCode.impl;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fd.vplus.dmc.userexit.common.DMUserExitInterface;


public class DMCustomCodeAtFromEndpointExit implements DMUserExitInterface {

	public byte[] execute(byte[] incomingBytes,  String encoding) {



		final Logger logger = LoggerFactory.getLogger(DMCustomCodeAtFromEndpointExit.class);   

		if (logger.isInfoEnabled()) {
			logger.info("inside the custom-code at from-endpoint exit" );			
		}

		if (incomingBytes == null || incomingBytes.length == 0) {
			if (logger.isInfoEnabled()) {
				logger.info("No incoming bytes received");					
			}			
		} else {

			if (logger.isTraceEnabled()) {
				try {
					logger.trace("message data recieved" +  new String (incomingBytes, encoding));
				} catch (UnsupportedEncodingException e) {
					logger.error("unsopported encoding" + encoding);				
				}
			}
		}

		return 	incomingBytes;

	}

}
