package com.fd.vplus.dmc.userexit.common;

import java.util.Properties;

public interface DMUserExitInterface {
	
	public byte[] execute (byte[] incomingBytes, String encoding);
}
