var result="NONE";
if (logEvent.getMessage() != null) {
         var msg = logEvent.getMessage().getFormattedMessage();
         if (msg.contains("Message sent") || msg.contains("outside system") || msg.contains("Response from") || msg.contains("String at Request")) {
           result = "YES";
 }       
}
result;
