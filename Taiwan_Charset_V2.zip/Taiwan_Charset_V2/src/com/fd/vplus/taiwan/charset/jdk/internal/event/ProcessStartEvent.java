/*
 * Copyright (c) 2020, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.fd.vplus.taiwan.charset.jdk.internal.event;

/**
 * Event for the start of an OS procsss
 */

public final class ProcessStartEvent extends Event {
    public long pid;
    public String directory;
    public String command;
}
